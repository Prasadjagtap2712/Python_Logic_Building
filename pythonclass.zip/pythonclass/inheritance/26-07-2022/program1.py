

class parent:
    x = 10
    def __init__(self):
        self.y = 20

    def disp(self):
        print(self.x)
        print(self.y)

    @classmethod
    def show(cls):
        print(cls.x)

obj1 = parent()

obj2 = parent()
obj1.x = 30
obj1.disp()  # 30 20
obj2.disp() # 10 20
obj1.show() # 10

parent.x = 40
obj1.disp()  # 30 20
obj1.show() # 40
