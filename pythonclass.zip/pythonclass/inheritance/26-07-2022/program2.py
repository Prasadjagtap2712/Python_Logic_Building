
class SBI:
    rules = "Rules"

    def __init__(self):
        self.exchangeName = "BSE"

    def transferingShares(self):
        print("Shares Transfers...")

    @classmethod 
    def applyForIPO(cls):
        print("Applied for IPO")

class Sensex(SBI):
    indexPrice = 55000

    def __init__(self,shareName,Sprice,exchangeName):
        super().__init__()
        self.shareName = shareName 
        self.Sprice = Sprice
        self.exchangeName = exchangeName

    def valuation(self):
        print(self.shareName)
        print(self.Sprice)
        print(self.exchangeName)
        print("valuation")

    @classmethod
    def showChart(self):
        print("Chart")


stock1 = Sensex("TATA",5500,"Sensex")
print(stock1.exchangeName)
stock1.transferingShares()
stock1.valuation()
stock1.showChart()
