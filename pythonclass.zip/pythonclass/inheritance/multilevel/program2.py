
class parent(object):
    x = 10

    def __init__(self):
        print("In Parent Constructure")
        self.y = 20

    @classmethod
    def show(cls):
        print(cls.x)

    def disp(self):
        print(self.x)
        print(self.y)

class child(parent):
    x = 110
    def __init__(self):
        super().__init__()
        print("Child Constructor")

    def childDisp(self):
        print(super().x)
        print(self.x)

obj = child()
obj.childDisp()
        
    

