

class parent(object):
    x = 10
    def __init__(self):
        print("Parent Constructure")
        self.y = 20

    @classmethod
    def show(cls):
        print(cls.x)

    def disp(self):
        print(self.x)
        print(self.y) 
       
class child(parent):
    def __init__(self):
        super().__init__()
        print("Child Constructor")

    def dispchild(self):
        print(self.x)

obj = child()
obj.dispchild()

obj.show()
obj.disp()
