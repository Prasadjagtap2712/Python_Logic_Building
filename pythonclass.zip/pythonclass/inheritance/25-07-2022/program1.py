
class company:
    def __init__(self):
        print("In parent constructor")
        self.cname = "IBM"
        self.ename = "ABC"

    def info(self):
        print(self.cname)
        print(self.ename)


class employee:
    def __init__(self):
        print("IN child classs")
        self.salary = 100000

    def disp(self):
        super().__init__()
        self.info()
        print(self.salary)

obj = employee()
obj.disp()



